<!doctype html>
<html lang="en">
<head>
<title>Tambah Data Kontrak</title>
</head>
<body>
<h1>Tambah</h1>
<a href="indexktk.php">Kembali</a><br><br>
<form action="prosesktk.php" method="post">
<label>Matakuliah_ID</label><br>
<input type="text" name="mk_id"><br>
<label>Nama</label><br>
<input type="text" name="nama"><br>

<br><br>
<button type="submit" name="submit_simpan">Submit</button>
<button type="reset">Reset</button>
</form>
</body>
</html>
