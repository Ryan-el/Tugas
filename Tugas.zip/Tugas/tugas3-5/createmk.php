<!doctype html>
<html lang="en">
<head>
<title>Tambah Data Matakuliah</title>
</head>
<body>
<h1>Tambah</h1>
<a href="indexmk.php">Kembali</a><br><br>
<form action="prosesmk.php" method="post">
<label>NIM</label><br>
<input type="text" name="nim"><br>
<label>Nama MK</label><br>
<input type="text" name="nama_mk"><br>

<br><br>
<button type="submit" name="submit_simpan">Submit</button>
<button type="reset">Reset</button>
</form>
</body>
</html>
