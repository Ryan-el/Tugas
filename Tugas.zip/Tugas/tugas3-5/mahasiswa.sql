-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2021 at 05:43 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.4.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mahasiswa`
--

-- --------------------------------------------------------

--
-- Table structure for table `kontrak_mk`
--

CREATE TABLE `kontrak_mk` (
  `mk_id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kontrak_mk`
--

INSERT INTO `kontrak_mk` (`mk_id`, `nama`) VALUES
(90085, 'michelle');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ab`
--

CREATE TABLE `tbl_ab` (
  `nim` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `mk_id` int(11) DEFAULT NULL,
  `wkt_absen` int(11) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_ab`
--

INSERT INTO `tbl_ab` (`nim`, `nama`, `mk_id`, `wkt_absen`, `status`) VALUES
(2015223005, 'michelle', 90085, 8, 'Hadir'),
(2015223006, 'michael', 90085, 10, 'Tidak Hadir');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mhs`
--

CREATE TABLE `tbl_mhs` (
  `nim` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `semester` int(11) DEFAULT NULL,
  `alamat` varchar(50) DEFAULT NULL,
  `telepon` int(11) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_mhs`
--

INSERT INTO `tbl_mhs` (`nim`, `nama`, `semester`, `alamat`, `telepon`, `email`) VALUES
(2015223005, 'michelle', 4, 'Kesambi', 555666444, 'michelle@yahoo.co.id'),
(2015223006, 'michael', 6, 'Perum', 845312666, 'michael@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mk`
--

CREATE TABLE `tbl_mk` (
  `nim` int(11) NOT NULL,
  `nama_mk` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_mk`
--

INSERT INTO `tbl_mk` (`nim`, `nama_mk`) VALUES
(2015223005, 'ansi');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nilai`
--

CREATE TABLE `tbl_nilai` (
  `nim` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `uts` int(11) NOT NULL,
  `uas` int(11) NOT NULL,
  `tugas` int(11) NOT NULL,
  `na` int(11) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_nilai`
--

INSERT INTO `tbl_nilai` (`nim`, `nama`, `uts`, `uas`, `tugas`, `na`, `status`) VALUES
(2015223005, 'michelle', 70, 85, 90, 82, 'Lulus'),
(2015223006, 'michael', 85, 100, 90, 93, 'Lulus');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kontrak_mk`
--
ALTER TABLE `kontrak_mk`
  ADD PRIMARY KEY (`mk_id`);

--
-- Indexes for table `tbl_ab`
--
ALTER TABLE `tbl_ab`
  ADD KEY `nim` (`nim`),
  ADD KEY `mk_id` (`mk_id`);

--
-- Indexes for table `tbl_mhs`
--
ALTER TABLE `tbl_mhs`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `tbl_mk`
--
ALTER TABLE `tbl_mk`
  ADD KEY `nim` (`nim`);

--
-- Indexes for table `tbl_nilai`
--
ALTER TABLE `tbl_nilai`
  ADD KEY `nim` (`nim`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_ab`
--
ALTER TABLE `tbl_ab`
  ADD CONSTRAINT `tbl_ab_ibfk_1` FOREIGN KEY (`nim`) REFERENCES `tbl_mhs` (`nim`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_ab_ibfk_2` FOREIGN KEY (`mk_id`) REFERENCES `kontrak_mk` (`mk_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_mk`
--
ALTER TABLE `tbl_mk`
  ADD CONSTRAINT `tbl_mk_ibfk_1` FOREIGN KEY (`nim`) REFERENCES `tbl_mhs` (`nim`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tbl_nilai`
--
ALTER TABLE `tbl_nilai`
  ADD CONSTRAINT `tbl_nilai_ibfk_1` FOREIGN KEY (`nim`) REFERENCES `tbl_mhs` (`nim`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
